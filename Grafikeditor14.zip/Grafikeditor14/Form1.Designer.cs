﻿namespace Grafikeditor14
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.skinControl1 = new technicontrol.Visualization.SkinControl();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dateiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.beendenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6_layout_laden = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6_layoutordner_öffnen = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new Grafikeditor14.Controls.CanvasPanel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripMenuItemOK_Panelgröße = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox3 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripMenuItemOK_Rastergröße = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemSchließen_Rastergröße = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton_ToggleLabelPanel = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripStatusLabelMode = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.skinControl8 = new technicontrol.Visualization.SkinControl();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.radioButton_linksbündig = new System.Windows.Forms.RadioButton();
            this.radioButton_zentriert = new System.Windows.Forms.RadioButton();
            this.radioButton_rechtsbündig = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.sC_B_ansichauswahl = new technicontrol.Visualization.SkinControl();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox2_ansicht = new System.Windows.Forms.ComboBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.sC_B_ansichtSpeichernFür = new technicontrol.Visualization.SkinControl();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox3_ansichtSpeichern = new System.Windows.Forms.ComboBox();
            this.sC_B_Speichern = new technicontrol.Visualization.SkinControl();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rTB_vorgabetext = new System.Windows.Forms.RichTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.p_hintergrundfarbe = new System.Windows.Forms.Panel();
            this.sC_B_hintergrundfarbe = new technicontrol.Visualization.SkinControl();
            this.panel10 = new System.Windows.Forms.Panel();
            this.sC_B_textfarbe = new technicontrol.Visualization.SkinControl();
            this.p_textfarbe = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.sC_B_Schriftart = new technicontrol.Visualization.SkinControl();
            this.rTB_schriftart = new System.Windows.Forms.RichTextBox();
            this.gB_Modi = new System.Windows.Forms.GroupBox();
            this.sC_B_NeuFelErz_Anw = new technicontrol.Visualization.SkinControl();
            this.tableLayoutPanel1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.skinControl8.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel12.SuspendLayout();
            this.gB_Modi.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.statusStrip1, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.skinControl1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.menuStrip1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tabControl1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 396F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1200, 1000);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 980);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1200, 20);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 15);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(118, 15);
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // skinControl1
            // 
            this.skinControl1.AutoSize = false;
            this.skinControl1.BackColor = System.Drawing.Color.Transparent;
            this.skinControl1.Checked = false;
            this.skinControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinControl1.ForeColor = System.Drawing.Color.White;
            this.skinControl1.Frame = 2;
            this.skinControl1.Location = new System.Drawing.Point(3, 3);
            this.skinControl1.Name = "skinControl1";
            this.skinControl1.Size = new System.Drawing.Size(1194, 45);
            this.skinControl1.SkinName = "Label Gloss 01 - Green";
            this.skinControl1.TabIndex = 0;
            this.skinControl1.Text = "Grafikeditor";
            this.skinControl1.TextPadding = new System.Windows.Forms.Padding(0);
            this.skinControl1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form_MouseDown);
            this.skinControl1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form_MouseMove);
            this.skinControl1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form_MouseUp);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dateiToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 51);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1200, 23);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dateiToolStripMenuItem
            // 
            this.dateiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.beendenToolStripMenuItem,
            this.toolStripMenuItem6_layout_laden,
            this.toolStripMenuItem6_layoutordner_öffnen});
            this.dateiToolStripMenuItem.Name = "dateiToolStripMenuItem";
            this.dateiToolStripMenuItem.Size = new System.Drawing.Size(46, 19);
            this.dateiToolStripMenuItem.Text = "Datei";
            // 
            // beendenToolStripMenuItem
            // 
            this.beendenToolStripMenuItem.Name = "beendenToolStripMenuItem";
            this.beendenToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.beendenToolStripMenuItem.Text = "Beenden";
            this.beendenToolStripMenuItem.Click += new System.EventHandler(this.beendenToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6_layout_laden
            // 
            this.toolStripMenuItem6_layout_laden.Name = "toolStripMenuItem6_layout_laden";
            this.toolStripMenuItem6_layout_laden.Size = new System.Drawing.Size(187, 22);
            this.toolStripMenuItem6_layout_laden.Text = "Layout/Ansicht laden";
            this.toolStripMenuItem6_layout_laden.Click += new System.EventHandler(this.mnuLayoutLaden_Click);
            // 
            // toolStripMenuItem6_layoutordner_öffnen
            // 
            this.toolStripMenuItem6_layoutordner_öffnen.Name = "toolStripMenuItem6_layoutordner_öffnen";
            this.toolStripMenuItem6_layoutordner_öffnen.Size = new System.Drawing.Size(187, 22);
            this.toolStripMenuItem6_layoutordner_öffnen.Text = "Layoutordner öffnen";
            this.toolStripMenuItem6_layoutordner_öffnen.Click += new System.EventHandler(this.mnuExplorer_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 77);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1194, 390);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.BackColor = System.Drawing.Color.ForestGreen;
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1186, 359);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Terminalansichten";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(20, 20);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(3);
            this.panel1.Size = new System.Drawing.Size(1146, 319);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.RasterAbstand = 10;
            this.panel2.RasterAktiv = false;
            this.panel2.RasterFarbe = System.Drawing.Color.LightGray;
            this.panel2.Size = new System.Drawing.Size(1140, 313);
            this.panel2.TabIndex = 0;
            this.panel2.SizeChanged += new System.EventHandler(this.panel2_SizeChanged);
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseDown);
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1186, 359);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tabellen";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1186, 359);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Merkmale / Farben";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 27);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1186, 359);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Kommentare";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.toolStrip1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 473);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1194, 504);
            this.tableLayoutPanel2.TabIndex = 4;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.toolStripSeparator4,
            this.toolStripDropDownButton2,
            this.toolStripSeparator1,
            this.toolStripButton_ToggleLabelPanel,
            this.toolStripSeparator3,
            this.toolStripStatusLabelMode,
            this.toolStripSeparator6});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1194, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripTextBox1,
            this.toolStripMenuItem2,
            this.toolStripTextBox2,
            this.toolStripMenuItemOK_Panelgröße});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(80, 22);
            this.toolStripDropDownButton1.Text = "Panelgröße";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem1.Text = "Breite";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 23);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Enabled = false;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem2.Text = "Höhe";
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(100, 23);
            // 
            // toolStripMenuItemOK_Panelgröße
            // 
            this.toolStripMenuItemOK_Panelgröße.Name = "toolStripMenuItemOK_Panelgröße";
            this.toolStripMenuItemOK_Panelgröße.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItemOK_Panelgröße.Text = "OK";
            this.toolStripMenuItemOK_Panelgröße.Click += new System.EventHandler(this.toolStripMenuItemOK_Panelgröße_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripTextBox3,
            this.toolStripMenuItemOK_Rastergröße,
            this.toolStripMenuItemSchließen_Rastergröße});
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(52, 22);
            this.toolStripDropDownButton2.Text = "Raster";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem3.Text = "An";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem4.Text = "Aus";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Enabled = false;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem5.Text = "Rastergröße";
            // 
            // toolStripTextBox3
            // 
            this.toolStripTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolStripTextBox3.Name = "toolStripTextBox3";
            this.toolStripTextBox3.Size = new System.Drawing.Size(100, 23);
            // 
            // toolStripMenuItemOK_Rastergröße
            // 
            this.toolStripMenuItemOK_Rastergröße.Name = "toolStripMenuItemOK_Rastergröße";
            this.toolStripMenuItemOK_Rastergröße.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItemOK_Rastergröße.Text = "OK";
            this.toolStripMenuItemOK_Rastergröße.Click += new System.EventHandler(this.toolStripMenuItemOK_Rastergröße_Click);
            // 
            // toolStripMenuItemSchließen_Rastergröße
            // 
            this.toolStripMenuItemSchließen_Rastergröße.Name = "toolStripMenuItemSchließen_Rastergröße";
            this.toolStripMenuItemSchließen_Rastergröße.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItemSchließen_Rastergröße.Text = "Schließen";
            this.toolStripMenuItemSchließen_Rastergröße.Click += new System.EventHandler(this.toolStripMenuItemSchließen_Rastergröße_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton_ToggleLabelPanel
            // 
            this.toolStripButton_ToggleLabelPanel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton_ToggleLabelPanel.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_ToggleLabelPanel.Image")));
            this.toolStripButton_ToggleLabelPanel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_ToggleLabelPanel.Name = "toolStripButton_ToggleLabelPanel";
            this.toolStripButton_ToggleLabelPanel.Size = new System.Drawing.Size(118, 22);
            this.toolStripButton_ToggleLabelPanel.Text = "Toggle Label / Panel";
            this.toolStripButton_ToggleLabelPanel.Click += new System.EventHandler(this.toolStripButton_ToggleLabelPanel_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripStatusLabelMode
            // 
            this.toolStripStatusLabelMode.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripStatusLabelMode.Name = "toolStripStatusLabelMode";
            this.toolStripStatusLabelMode.Size = new System.Drawing.Size(98, 22);
            this.toolStripStatusLabelMode.Text = "Modus: Erzeugen";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.32997F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.59596F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.20539F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.78451F));
            this.tableLayoutPanel3.Controls.Add(this.skinControl8, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.groupBox3, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.groupBox5, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.flowLayoutPanel4, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 28);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 473F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1188, 473);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // skinControl8
            // 
            this.skinControl8.AutoSize = false;
            this.skinControl8.BackColor = System.Drawing.Color.Transparent;
            this.skinControl8.Checked = false;
            this.skinControl8.Controls.Add(this.flowLayoutPanel6);
            this.skinControl8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinControl8.ForeColor = System.Drawing.Color.White;
            this.skinControl8.Frame = 2;
            this.skinControl8.Location = new System.Drawing.Point(753, 3);
            this.skinControl8.Name = "skinControl8";
            this.skinControl8.Size = new System.Drawing.Size(432, 467);
            this.skinControl8.SkinName = "Vox Panel 01.02";
            this.skinControl8.TabIndex = 0;
            this.skinControl8.Text = "Tastenkombinationen";
            this.skinControl8.TextPadding = new System.Windows.Forms.Padding(0);
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel6.Controls.Add(this.richTextBox3);
            this.flowLayoutPanel6.Controls.Add(this.richTextBox4);
            this.flowLayoutPanel6.Controls.Add(this.richTextBox5);
            this.flowLayoutPanel6.Controls.Add(this.richTextBox6);
            this.flowLayoutPanel6.Controls.Add(this.richTextBox7);
            this.flowLayoutPanel6.Location = new System.Drawing.Point(13, 32);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(402, 415);
            this.flowLayoutPanel6.TabIndex = 9;
            // 
            // richTextBox3
            // 
            this.richTextBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox3.Location = new System.Drawing.Point(3, 3);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(395, 27);
            this.richTextBox3.TabIndex = 0;
            this.richTextBox3.Text = "STRG + Linksklick: Element duplizieren";
            // 
            // richTextBox4
            // 
            this.richTextBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox4.Location = new System.Drawing.Point(3, 36);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(395, 27);
            this.richTextBox4.TabIndex = 1;
            this.richTextBox4.Text = "Linksklick: Element auswählen";
            // 
            // richTextBox5
            // 
            this.richTextBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox5.Location = new System.Drawing.Point(3, 69);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(395, 27);
            this.richTextBox5.TabIndex = 2;
            this.richTextBox5.Text = "Pfeiltasten: ausgewähltes Element verschieben";
            // 
            // richTextBox6
            // 
            this.richTextBox6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox6.Location = new System.Drawing.Point(3, 102);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.Size = new System.Drawing.Size(395, 27);
            this.richTextBox6.TabIndex = 3;
            this.richTextBox6.Text = "SHIFT + Pfeiltasten: Größe ändern";
            // 
            // richTextBox7
            // 
            this.richTextBox7.Location = new System.Drawing.Point(3, 135);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.Size = new System.Drawing.Size(395, 278);
            this.richTextBox7.TabIndex = 4;
            this.richTextBox7.Text = "";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.flowLayoutPanel5);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(608, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(139, 467);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Textanordnung";
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Controls.Add(this.radioButton_linksbündig);
            this.flowLayoutPanel5.Controls.Add(this.radioButton_zentriert);
            this.flowLayoutPanel5.Controls.Add(this.radioButton_rechtsbündig);
            this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(3, 22);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(133, 442);
            this.flowLayoutPanel5.TabIndex = 0;
            // 
            // radioButton_linksbündig
            // 
            this.radioButton_linksbündig.AutoSize = true;
            this.radioButton_linksbündig.Location = new System.Drawing.Point(3, 3);
            this.radioButton_linksbündig.Name = "radioButton_linksbündig";
            this.radioButton_linksbündig.Size = new System.Drawing.Size(110, 22);
            this.radioButton_linksbündig.TabIndex = 0;
            this.radioButton_linksbündig.TabStop = true;
            this.radioButton_linksbündig.Text = "Linksbündig";
            this.radioButton_linksbündig.UseVisualStyleBackColor = true;
            this.radioButton_linksbündig.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // radioButton_zentriert
            // 
            this.radioButton_zentriert.AutoSize = true;
            this.radioButton_zentriert.Checked = true;
            this.radioButton_zentriert.Location = new System.Drawing.Point(3, 31);
            this.radioButton_zentriert.Name = "radioButton_zentriert";
            this.radioButton_zentriert.Size = new System.Drawing.Size(83, 22);
            this.radioButton_zentriert.TabIndex = 1;
            this.radioButton_zentriert.TabStop = true;
            this.radioButton_zentriert.Text = "Zentriert";
            this.radioButton_zentriert.UseVisualStyleBackColor = true;
            this.radioButton_zentriert.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // radioButton_rechtsbündig
            // 
            this.radioButton_rechtsbündig.AutoSize = true;
            this.radioButton_rechtsbündig.Location = new System.Drawing.Point(3, 59);
            this.radioButton_rechtsbündig.Name = "radioButton_rechtsbündig";
            this.radioButton_rechtsbündig.Size = new System.Drawing.Size(121, 22);
            this.radioButton_rechtsbündig.TabIndex = 2;
            this.radioButton_rechtsbündig.TabStop = true;
            this.radioButton_rechtsbündig.Text = "Rechtsbündig";
            this.radioButton_rechtsbündig.UseVisualStyleBackColor = true;
            this.radioButton_rechtsbündig.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.flowLayoutPanel3);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(3, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(188, 467);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Ansichten";
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.sC_B_ansichauswahl);
            this.flowLayoutPanel3.Controls.Add(this.label3);
            this.flowLayoutPanel3.Controls.Add(this.comboBox2_ansicht);
            this.flowLayoutPanel3.Controls.Add(this.panel6);
            this.flowLayoutPanel3.Controls.Add(this.sC_B_ansichtSpeichernFür);
            this.flowLayoutPanel3.Controls.Add(this.label4);
            this.flowLayoutPanel3.Controls.Add(this.comboBox3_ansichtSpeichern);
            this.flowLayoutPanel3.Controls.Add(this.sC_B_Speichern);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(3, 22);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(182, 442);
            this.flowLayoutPanel3.TabIndex = 0;
            // 
            // sC_B_ansichauswahl
            // 
            this.sC_B_ansichauswahl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sC_B_ansichauswahl.AutoSize = false;
            this.sC_B_ansichauswahl.BackColor = System.Drawing.Color.Transparent;
            this.sC_B_ansichauswahl.Checked = false;
            this.sC_B_ansichauswahl.ForeColor = System.Drawing.Color.White;
            this.sC_B_ansichauswahl.Frame = 2;
            this.sC_B_ansichauswahl.Location = new System.Drawing.Point(3, 3);
            this.sC_B_ansichauswahl.Name = "sC_B_ansichauswahl";
            this.sC_B_ansichauswahl.Size = new System.Drawing.Size(179, 48);
            this.sC_B_ansichauswahl.SkinName = "Button Gloss 02.04";
            this.sC_B_ansichauswahl.TabIndex = 0;
            this.sC_B_ansichauswahl.Text = "Ansichtauswahl";
            this.sC_B_ansichauswahl.TextPadding = new System.Windows.Forms.Padding(0);
            this.sC_B_ansichauswahl.Click += new System.EventHandler(this.sC_B_ansichauswahl_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Location = new System.Drawing.Point(3, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(179, 27);
            this.label3.TabIndex = 1;
            this.label3.Text = "Ansicht";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox2_ansicht
            // 
            this.comboBox2_ansicht.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox2_ansicht.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2_ansicht.FormattingEnabled = true;
            this.comboBox2_ansicht.Location = new System.Drawing.Point(3, 84);
            this.comboBox2_ansicht.Name = "comboBox2_ansicht";
            this.comboBox2_ansicht.Size = new System.Drawing.Size(179, 26);
            this.comboBox2_ansicht.TabIndex = 2;
            this.comboBox2_ansicht.DropDown += new System.EventHandler(this.comboBox2_ansicht_DropDown);
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.Location = new System.Drawing.Point(3, 116);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(179, 13);
            this.panel6.TabIndex = 3;
            // 
            // sC_B_ansichtSpeichernFür
            // 
            this.sC_B_ansichtSpeichernFür.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sC_B_ansichtSpeichernFür.AutoSize = false;
            this.sC_B_ansichtSpeichernFür.BackColor = System.Drawing.Color.Transparent;
            this.sC_B_ansichtSpeichernFür.Checked = false;
            this.sC_B_ansichtSpeichernFür.ForeColor = System.Drawing.Color.White;
            this.sC_B_ansichtSpeichernFür.Frame = 2;
            this.sC_B_ansichtSpeichernFür.Location = new System.Drawing.Point(3, 135);
            this.sC_B_ansichtSpeichernFür.Name = "sC_B_ansichtSpeichernFür";
            this.sC_B_ansichtSpeichernFür.Size = new System.Drawing.Size(179, 48);
            this.sC_B_ansichtSpeichernFür.SkinName = "Button Gloss 02.04";
            this.sC_B_ansichtSpeichernFür.TabIndex = 3;
            this.sC_B_ansichtSpeichernFür.Text = "Ansicht speichern für";
            this.sC_B_ansichtSpeichernFür.TextPadding = new System.Windows.Forms.Padding(0);
            this.sC_B_ansichtSpeichernFür.Click += new System.EventHandler(this.sC_B_ansichtSpeichernFür_Click);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.Location = new System.Drawing.Point(3, 186);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(179, 27);
            this.label4.TabIndex = 4;
            this.label4.Text = "Ansicht";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox3_ansichtSpeichern
            // 
            this.comboBox3_ansichtSpeichern.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox3_ansichtSpeichern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3_ansichtSpeichern.FormattingEnabled = true;
            this.comboBox3_ansichtSpeichern.Location = new System.Drawing.Point(3, 216);
            this.comboBox3_ansichtSpeichern.Name = "comboBox3_ansichtSpeichern";
            this.comboBox3_ansichtSpeichern.Size = new System.Drawing.Size(179, 26);
            this.comboBox3_ansichtSpeichern.Sorted = true;
            this.comboBox3_ansichtSpeichern.TabIndex = 5;
            // 
            // sC_B_Speichern
            // 
            this.sC_B_Speichern.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sC_B_Speichern.AutoSize = false;
            this.sC_B_Speichern.BackColor = System.Drawing.Color.Transparent;
            this.sC_B_Speichern.Checked = false;
            this.sC_B_Speichern.ForeColor = System.Drawing.Color.White;
            this.sC_B_Speichern.Frame = 2;
            this.sC_B_Speichern.Location = new System.Drawing.Point(3, 248);
            this.sC_B_Speichern.Name = "sC_B_Speichern";
            this.sC_B_Speichern.Size = new System.Drawing.Size(179, 48);
            this.sC_B_Speichern.SkinName = "Button Gloss 03.16";
            this.sC_B_Speichern.TabIndex = 6;
            this.sC_B_Speichern.Text = "Speichern";
            this.sC_B_Speichern.TextPadding = new System.Windows.Forms.Padding(0);
            this.sC_B_Speichern.Click += new System.EventHandler(this.sC_B_Speichern_Click);
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Controls.Add(this.groupBox1);
            this.flowLayoutPanel4.Controls.Add(this.groupBox2);
            this.flowLayoutPanel4.Controls.Add(this.gB_Modi);
            this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(197, 3);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(405, 467);
            this.flowLayoutPanel4.TabIndex = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.flowLayoutPanel1);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(381, 148);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Feldinhalt";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.label1);
            this.flowLayoutPanel1.Controls.Add(this.comboBox1);
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.rTB_vorgabetext);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 22);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(375, 123);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Auftragsmerkmal";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "*AB03300_B Anzahl Schweissungen",
            "",
            "*AB03300_B Schweissung 01 Position",
            "",
            "*AB03300_B Schweissung 01 Werkzeug",
            "",
            "*AB03300_B Schweissung 02 Position",
            "",
            "*AB03300_B Schweissung 02 Werkzeug",
            "",
            "*AB03300_B Schweissung 03 Position",
            "",
            "*AB03300_B Schweissung 03 Werkzeug",
            "",
            "*AB03300_B Schweissung 04 Position",
            "",
            "*AB03300_B Schweissung 04 Werkzeug",
            "",
            "*AB03300_B Schweissung 05 Position",
            "",
            "*AB03300_Bodeneinstand",
            "",
            "*AB03300_S Anzahl Schweissungen",
            "",
            "*AB03300_S Schweissung 01 Position",
            "",
            "*AB03300_S Schweissung 01 Werkzeug",
            "",
            "*AB03300_S Schweissung 02 Position",
            "",
            "*AB03300_S Schweissung 02 Werkzeug",
            "",
            "*AB03300_S Schweissung 03 Position",
            "",
            "*AB03300_S Schweissung 03 Werkzeug",
            "",
            "*AB03300_S Schweissung 04 Position",
            "",
            "*AB03300_S Schweissung 04 Werkzeug",
            "",
            "*AB03300_S Schweissung 05 Position",
            "",
            "*AB03300_S Schweissung 05 Werkzeug",
            "",
            "*AB03310_Ausschleusen",
            "",
            "*AB03310_B Schweissung 05 Werkzeug",
            "",
            "Blechoberflaeche",
            "",
            "BRB",
            "",
            "BRH",
            "",
            "DIN",
            "",
            "Einreicher",
            "",
            "Falzmassbreite",
            "",
            "Falzmasshoehe",
            "",
            "Freigabe",
            "",
            "Rest",
            "",
            "Soll",
            "",
            "Werkauftrag",
            "",
            "_Kommentarfeld"});
            this.comboBox1.Location = new System.Drawing.Point(3, 25);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(369, 26);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Location = new System.Drawing.Point(3, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Vorgabetext";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rTB_vorgabetext
            // 
            this.rTB_vorgabetext.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rTB_vorgabetext.Location = new System.Drawing.Point(3, 81);
            this.rTB_vorgabetext.Name = "rTB_vorgabetext";
            this.rTB_vorgabetext.Size = new System.Drawing.Size(369, 27);
            this.rTB_vorgabetext.TabIndex = 3;
            this.rTB_vorgabetext.Text = "";
            this.rTB_vorgabetext.TextChanged += new System.EventHandler(this.rTB_vorgabetext_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.flowLayoutPanel2);
            this.groupBox2.Location = new System.Drawing.Point(3, 157);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(381, 191);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Farbe und Schriftart";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.panel5);
            this.flowLayoutPanel2.Controls.Add(this.panel10);
            this.flowLayoutPanel2.Controls.Add(this.panel12);
            this.flowLayoutPanel2.Controls.Add(this.rTB_schriftart);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 22);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(375, 166);
            this.flowLayoutPanel2.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.Controls.Add(this.p_hintergrundfarbe);
            this.panel5.Controls.Add(this.sC_B_hintergrundfarbe);
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(369, 33);
            this.panel5.TabIndex = 6;
            // 
            // p_hintergrundfarbe
            // 
            this.p_hintergrundfarbe.BackColor = System.Drawing.SystemColors.Control;
            this.p_hintergrundfarbe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.p_hintergrundfarbe.Location = new System.Drawing.Point(160, 3);
            this.p_hintergrundfarbe.Name = "p_hintergrundfarbe";
            this.p_hintergrundfarbe.Size = new System.Drawing.Size(27, 27);
            this.p_hintergrundfarbe.TabIndex = 1;
            // 
            // sC_B_hintergrundfarbe
            // 
            this.sC_B_hintergrundfarbe.AutoSize = false;
            this.sC_B_hintergrundfarbe.BackColor = System.Drawing.Color.Transparent;
            this.sC_B_hintergrundfarbe.Checked = false;
            this.sC_B_hintergrundfarbe.ForeColor = System.Drawing.Color.White;
            this.sC_B_hintergrundfarbe.Frame = 2;
            this.sC_B_hintergrundfarbe.Location = new System.Drawing.Point(3, 3);
            this.sC_B_hintergrundfarbe.Name = "sC_B_hintergrundfarbe";
            this.sC_B_hintergrundfarbe.Size = new System.Drawing.Size(151, 27);
            this.sC_B_hintergrundfarbe.SkinName = "Button Gloss Black 01";
            this.sC_B_hintergrundfarbe.TabIndex = 0;
            this.sC_B_hintergrundfarbe.Text = "Hintergrundfarbe";
            this.sC_B_hintergrundfarbe.TextPadding = new System.Windows.Forms.Padding(0);
            this.sC_B_hintergrundfarbe.Click += new System.EventHandler(this.sC_B_hintergrundfarbe_Click);
            // 
            // panel10
            // 
            this.panel10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel10.Controls.Add(this.sC_B_textfarbe);
            this.panel10.Controls.Add(this.p_textfarbe);
            this.panel10.Location = new System.Drawing.Point(3, 42);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(369, 33);
            this.panel10.TabIndex = 7;
            // 
            // sC_B_textfarbe
            // 
            this.sC_B_textfarbe.AutoSize = false;
            this.sC_B_textfarbe.BackColor = System.Drawing.Color.Transparent;
            this.sC_B_textfarbe.Checked = false;
            this.sC_B_textfarbe.ForeColor = System.Drawing.Color.White;
            this.sC_B_textfarbe.Frame = 2;
            this.sC_B_textfarbe.Location = new System.Drawing.Point(3, 3);
            this.sC_B_textfarbe.Name = "sC_B_textfarbe";
            this.sC_B_textfarbe.Size = new System.Drawing.Size(151, 27);
            this.sC_B_textfarbe.SkinName = "Button Gloss Black 01";
            this.sC_B_textfarbe.TabIndex = 2;
            this.sC_B_textfarbe.Text = "Textfarbe";
            this.sC_B_textfarbe.TextPadding = new System.Windows.Forms.Padding(0);
            this.sC_B_textfarbe.Click += new System.EventHandler(this.sC_B_textfarbe_Click);
            // 
            // p_textfarbe
            // 
            this.p_textfarbe.BackColor = System.Drawing.Color.Black;
            this.p_textfarbe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.p_textfarbe.Location = new System.Drawing.Point(160, 3);
            this.p_textfarbe.Name = "p_textfarbe";
            this.p_textfarbe.Size = new System.Drawing.Size(27, 27);
            this.p_textfarbe.TabIndex = 3;
            // 
            // panel12
            // 
            this.panel12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel12.Controls.Add(this.sC_B_Schriftart);
            this.panel12.Location = new System.Drawing.Point(3, 81);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(369, 33);
            this.panel12.TabIndex = 8;
            // 
            // sC_B_Schriftart
            // 
            this.sC_B_Schriftart.AutoSize = false;
            this.sC_B_Schriftart.BackColor = System.Drawing.Color.Transparent;
            this.sC_B_Schriftart.Checked = false;
            this.sC_B_Schriftart.ForeColor = System.Drawing.Color.White;
            this.sC_B_Schriftart.Frame = 2;
            this.sC_B_Schriftart.Location = new System.Drawing.Point(3, 3);
            this.sC_B_Schriftart.Name = "sC_B_Schriftart";
            this.sC_B_Schriftart.Size = new System.Drawing.Size(151, 27);
            this.sC_B_Schriftart.SkinName = "Button Gloss Black 01";
            this.sC_B_Schriftart.TabIndex = 4;
            this.sC_B_Schriftart.Text = "Schriftart";
            this.sC_B_Schriftart.TextPadding = new System.Windows.Forms.Padding(0);
            this.sC_B_Schriftart.Click += new System.EventHandler(this.sC_B_Schriftart_Click);
            // 
            // rTB_schriftart
            // 
            this.rTB_schriftart.Location = new System.Drawing.Point(3, 120);
            this.rTB_schriftart.Name = "rTB_schriftart";
            this.rTB_schriftart.Size = new System.Drawing.Size(369, 30);
            this.rTB_schriftart.TabIndex = 5;
            this.rTB_schriftart.Text = "Arial, 12, Bold";
            // 
            // gB_Modi
            // 
            this.gB_Modi.Controls.Add(this.sC_B_NeuFelErz_Anw);
            this.gB_Modi.Location = new System.Drawing.Point(3, 354);
            this.gB_Modi.Name = "gB_Modi";
            this.gB_Modi.Size = new System.Drawing.Size(390, 110);
            this.gB_Modi.TabIndex = 10;
            this.gB_Modi.TabStop = false;
            this.gB_Modi.Text = "Modi";
            // 
            // sC_B_NeuFelErz_Anw
            // 
            this.sC_B_NeuFelErz_Anw.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sC_B_NeuFelErz_Anw.AutoSize = false;
            this.sC_B_NeuFelErz_Anw.BackColor = System.Drawing.Color.Transparent;
            this.sC_B_NeuFelErz_Anw.Checked = false;
            this.sC_B_NeuFelErz_Anw.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sC_B_NeuFelErz_Anw.ForeColor = System.Drawing.Color.White;
            this.sC_B_NeuFelErz_Anw.Frame = 2;
            this.sC_B_NeuFelErz_Anw.Location = new System.Drawing.Point(6, 23);
            this.sC_B_NeuFelErz_Anw.Name = "sC_B_NeuFelErz_Anw";
            this.sC_B_NeuFelErz_Anw.Size = new System.Drawing.Size(182, 32);
            this.sC_B_NeuFelErz_Anw.SkinName = "Button Gloss 02.04";
            this.sC_B_NeuFelErz_Anw.TabIndex = 10;
            this.sC_B_NeuFelErz_Anw.Text = "Neues Feld erzeugen";
            this.sC_B_NeuFelErz_Anw.TextPadding = new System.Windows.Forms.Padding(0);
            this.sC_B_NeuFelErz_Anw.Click += new System.EventHandler(this.sC_B_NeuFelErz_Anw_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 1000);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.skinControl8.ResumeLayout(false);
            this.flowLayoutPanel6.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel5.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.gB_Modi.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private technicontrol.Visualization.SkinControl skinControl1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dateiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem beendenToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private Grafikeditor14.Controls.CanvasPanel panel2;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemOK_Panelgröße;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemOK_Rastergröße;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemSchließen_Rastergröße;
        private System.Windows.Forms.ToolStripButton toolStripButton_ToggleLabelPanel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private technicontrol.Visualization.SkinControl sC_B_ansichauswahl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2_ansicht;
        private System.Windows.Forms.Panel panel6;
        private technicontrol.Visualization.SkinControl sC_B_ansichtSpeichernFür;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox3_ansichtSpeichern;
        private technicontrol.Visualization.SkinControl sC_B_Speichern;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.RichTextBox rTB_vorgabetext;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel p_hintergrundfarbe;
        private technicontrol.Visualization.SkinControl sC_B_hintergrundfarbe;
        private System.Windows.Forms.Panel panel10;
        private technicontrol.Visualization.SkinControl sC_B_textfarbe;
        private System.Windows.Forms.Panel p_textfarbe;
        private System.Windows.Forms.Panel panel12;
        private technicontrol.Visualization.SkinControl sC_B_Schriftart;
        private System.Windows.Forms.RichTextBox rTB_schriftart;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.RadioButton radioButton_linksbündig;
        private System.Windows.Forms.RadioButton radioButton_zentriert;
        private System.Windows.Forms.RadioButton radioButton_rechtsbündig;
        private technicontrol.Visualization.SkinControl skinControl8;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.ToolStripLabel toolStripStatusLabelMode;
        private System.Windows.Forms.GroupBox gB_Modi;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private technicontrol.Visualization.SkinControl sC_B_NeuFelErz_Anw;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6_layout_laden;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6_layoutordner_öffnen;
    }
}

