﻿// ============================================================
// Form1.Selection.cs – Verwaltung der Feldselektion
// Ziel: Auswahl logischer Steuerelemente im Zeichenbereich steuern
// .NET 4.0 kompatibel, vollständig kommentiert
// ============================================================

using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Grafikeditor14
{
    public partial class Form1 : Form
    {
        // Aktuell ausgewählte Steuerelemente
        private readonly List<Control> _selection = new List<Control>();

        // ============================================================
        // Fügt ein Steuerelement zur Auswahl hinzu und aktualisiert die Anzeige
        // ============================================================

        /// <summary>
        /// Fügt ein einzelnes Steuerelement zur aktuellen Auswahl hinzu
        /// und aktualisiert den Highlight-Rahmen und die Eigenschaftenanzeige.
        /// </summary>
        /// <param name="ctrl">Das hinzuzufügende Steuerelement.</param>
        private void AddToSelection(Control ctrl)
        {
            if (ctrl == null) return;

            ClearSelection(); // Nur eine Auswahl zulassen
            _selection.Add(ctrl);
            _state.ActiveControl = ctrl; // interner Status aktualisieren

            SyncControlsAndTag(ctrl);    // Anzeige synchronisieren
            AktualisiereHighlightRahmen(); // Auswahlrahmen aktualisieren
        }

        // ============================================================
        // Entfernt ein Steuerelement aus der Auswahl
        // ============================================================

        /// <summary>
        /// Entfernt ein einzelnes Steuerelement aus der aktuellen Auswahl.
        /// Falls keine Auswahl mehr verbleibt, wird alles zurückgesetzt.
        /// </summary>
        /// <param name="ctrl">Das zu entfernende Steuerelement.</param>
        private void RemoveFromSelection(Control ctrl)
        {
            _selection.Remove(ctrl);
            if (_selection.Count == 0)
            {
                ClearSelection();
            }
            else
            {
                AktualisiereHighlightRahmen();
                if (_selection.Count == 1)
                    DisplayFieldProperties(_selection[0]);
                else
                    richTextBox7.Clear();
            }
        }

        // ============================================================
        // Hebt alle Selektionen auf und leert die Anzeige
        // ============================================================

        /// <summary>
        /// Hebt die aktuelle Auswahl vollständig auf und entfernt den Auswahlrahmen.
        /// </summary>
        private void ClearSelection()
        {
            _selection.Clear();
            _state.ActiveControl = null;
            highlightBorder.Visible = false;
            richTextBox7.Clear();
        }
    }
}
